/**
 * Package contenant l'ensemble des tests JUnit4 / JUnit5
 */
package tests;