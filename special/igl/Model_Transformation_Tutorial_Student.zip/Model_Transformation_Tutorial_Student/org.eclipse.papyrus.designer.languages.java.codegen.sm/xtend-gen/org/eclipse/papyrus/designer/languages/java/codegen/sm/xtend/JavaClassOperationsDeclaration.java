/**
 * Copyright (c) 2006 - 2016 CEA LIST.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Shuai Li (CEA LIST) <shuai.li@cea.fr> - initial API and implementation
 */
package org.eclipse.papyrus.designer.languages.java.codegen.sm.xtend;

import java.util.Collection;
import org.eclipse.papyrus.designer.languages.common.base.GenUtils;
import org.eclipse.papyrus.designer.languages.common.profile.Codegen.NoCodeGen;
import org.eclipse.uml2.uml.Classifier;
import org.eclipse.uml2.uml.Operation;
import org.eclipse.xtend2.lib.StringConcatenation;

@SuppressWarnings("all")
public class JavaClassOperationsDeclaration {
  public static CharSequence javaClassOperationsDeclaration(final Classifier clazz) {
    StringConcatenation _builder = new StringConcatenation();
    {
      Collection<Operation> _ownedOperations = JavaOperations.getOwnedOperations(clazz);
      for(final Operation op : _ownedOperations) {
        _builder.newLine();
        {
          boolean _hasStereotype = GenUtils.hasStereotype(op, NoCodeGen.class);
          boolean _not = (!_hasStereotype);
          if (_not) {
            CharSequence _javaOperationDeclaration = JavaOperations.javaOperationDeclaration(op);
            _builder.append(_javaOperationDeclaration);
          }
        }
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
}
