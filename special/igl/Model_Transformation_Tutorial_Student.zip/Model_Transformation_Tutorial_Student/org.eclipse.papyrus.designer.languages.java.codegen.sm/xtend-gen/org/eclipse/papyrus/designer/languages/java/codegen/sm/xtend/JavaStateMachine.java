/**
 * Copyright (c) 2006 - 2016 CEA LIST.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Shuai Li (CEA LIST) <shuai.li@cea.fr> - initial API and implementation
 */
package org.eclipse.papyrus.designer.languages.java.codegen.sm.xtend;

import java.util.ArrayList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.uml2.uml.Behavior;
import org.eclipse.uml2.uml.Element;
import org.eclipse.uml2.uml.OpaqueBehavior;
import org.eclipse.uml2.uml.Pseudostate;
import org.eclipse.uml2.uml.State;
import org.eclipse.uml2.uml.StateMachine;
import org.eclipse.uml2.uml.Transition;
import org.eclipse.uml2.uml.Vertex;
import org.eclipse.xtend2.lib.StringConcatenation;

@SuppressWarnings("all")
public class JavaStateMachine {
  public static CharSequence javaStateMachineGeneration(final StateMachine stateMachine) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("private String currentState = \"");
    String _initialState = JavaStateMachine.getInitialState(stateMachine);
    _builder.append(_initialState);
    _builder.append("\";");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("private HashSet<String> states = new HashSet<>(Arrays.asList(");
    CharSequence _stateNames = JavaStateMachine.getStateNames(stateMachine);
    _builder.append(_stateNames);
    _builder.append("));");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("\t\t\t\t");
    _builder.append("private HashSet<String> transitions = new HashSet<>(Arrays.asList(");
    CharSequence _transitionNames = JavaStateMachine.getTransitionNames(stateMachine);
    _builder.append(_transitionNames, "\t\t\t\t");
    _builder.append("));");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.newLine();
    _builder.newLine();
    _builder.append("public void transit(String sourceState, String targetState) {");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("if (!states.contains(sourceState)) {");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("System.err.println(\"Invalid source state: \" + sourceState);");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("return;");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("if (!states.contains(targetState)) {");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("System.err.println(\"Invalid target state: \" + targetState);");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("return;");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("String transition = sourceState + \";\" + targetState;");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("if (transitions.contains(transition)) {");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("currentState = targetState;");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("} else {");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("System.err.println(\"Invalid transition: current state \" + currentState + \" cannot transit to \" + targetState);");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Utility method to get initial state or nothing
   * @param stateMachine the state machine to investigate
   * @return initial state
   */
  public static String getInitialState(final StateMachine stateMachine) {
    if ((stateMachine != null)) {
      EList<Element> _allOwnedElements = stateMachine.allOwnedElements();
      for (final Element ownedElement : _allOwnedElements) {
        if ((ownedElement instanceof Pseudostate)) {
          EList<Transition> _outgoings = ((Pseudostate) ownedElement).getOutgoings();
          for (final Transition outgoing : _outgoings) {
            Vertex _target = outgoing.getTarget();
            if ((_target instanceof State)) {
              return outgoing.getTarget().getName();
            }
          }
        }
      }
    }
    return "";
  }
  
  /**
   * Utility method to get all states from state Machine
   * @param stateMachine the state machine to investigate
   * @return all states in the state machine
   */
  public static ArrayList<State> getStates(final StateMachine stateMachine) {
    ArrayList<State> _xblockexpression = null;
    {
      ArrayList<State> states = new ArrayList<State>();
      _xblockexpression = states;
    }
    return _xblockexpression;
  }
  
  /**
   * Utility method to get all states names of the state machine
   * @param stateMachine the state machine to investigate
   * @return a list of states names in the state machine
   */
  public static ArrayList<String> getStateNamesList(final StateMachine stateMachine) {
    ArrayList<String> _xblockexpression = null;
    {
      ArrayList<String> stateNames = new ArrayList<String>();
      final ArrayList<State> states = JavaStateMachine.getStates(stateMachine);
      _xblockexpression = stateNames;
    }
    return _xblockexpression;
  }
  
  /**
   * Interpolated expression to get all state names separated by ", "
   */
  public static CharSequence getStateNames(final StateMachine stateMachine) {
    StringConcatenation _builder = new StringConcatenation();
    return _builder;
  }
  
  /**
   * Utility method to get all transitions of the state machine
   * @param stateMachine the state machine to investigate
   * @return all transitions in the state machine
   */
  public static ArrayList<Transition> getTransitions(final StateMachine stateMachine) {
    ArrayList<Transition> _xblockexpression = null;
    {
      ArrayList<Transition> transitions = new ArrayList<Transition>();
      _xblockexpression = transitions;
    }
    return _xblockexpression;
  }
  
  /**
   * Utility method to get all transition names of the state machine
   * @param stateMachine the state machine to investigate
   * @return a list of transitions names in the state machine relating source & targets spearated by ";"
   */
  public static ArrayList<String> getTransitionNamesList(final StateMachine stateMachine) {
    ArrayList<String> _xblockexpression = null;
    {
      ArrayList<String> transitionNames = new ArrayList<String>();
      final ArrayList<Transition> transitions = JavaStateMachine.getTransitions(stateMachine);
      _xblockexpression = transitionNames;
    }
    return _xblockexpression;
  }
  
  /**
   * Interpolated expression to get all transition names separated by ", "
   */
  public static CharSequence getTransitionNames(final StateMachine stateMachine) {
    StringConcatenation _builder = new StringConcatenation();
    return _builder;
  }
  
  /**
   * Builds the code for all exit behaviors
   * @param stateMachine the state machine to investigate
   * @code
   * 	switch (sourceState) {
   * 		case "«state name»":
   * 			// Call «state name» exit behavior
   * 			«state...javaBehavior»
   * 			break;
   * 		...
   * 	}
   * @endode
   * Only if at least one state has an exit behavior
   * @return the code for exit behaviors (if any)
   */
  public static void getExitBehaviors(final StateMachine stateMachine) {
    ArrayList<State> states = JavaStateMachine.getStates(stateMachine);
    String exitBehaviorCode = "";
  }
  
  /**
   * Builds the code for all entry behaviors
   * @param stateMachine the state machine to investigate
   * @code
   * 	switch (sourceState) {
   * 		case "«state name»":
   * 			// Call «state name» entry behavior
   * 			«state...javaBehavior»
   * 			break;
   * 		...
   * 	}
   * @endode
   * Only if at least one state has an entry behavior
   * @return the code for entry behaviors (if any)
   */
  public static void getEntryBehaviors(final StateMachine stateMachine) {
    ArrayList<State> states = JavaStateMachine.getStates(stateMachine);
    String entryBehaviorCode = "";
  }
  
  /**
   * Builds the code for all do activity behaviors
   * @param stateMachine the state machine to investigate
   * @code
   * 	switch (sourceState) {
   * 		case "«state name»":
   * 			// Call «state name» do activity behavior
   * 			«state...javaBehavior»
   * 			break;
   * 		...
   * 	}
   * @endode
   * Only if at least one state has an do activity behavior
   * @return the code for do activity behaviors (if any)
   */
  public static void getDoActivityBehaviors(final StateMachine stateMachine) {
    ArrayList<State> states = JavaStateMachine.getStates(stateMachine);
    String doActivityBehaviorCode = "";
  }
  
  /**
   * Builds the code for all transitions effect behaviors
   * @param stateMachine the state machine to investigate
   * @code
   * 	switch (transition) {
   * 		case "«transition name»":
   * 			// Call «transition name» effect behavior
   * 			«transition...javaBehavior»
   * 			break;
   * 		...
   * 	}
   * @endode
   * Only if at least one state has an do activity behavior
   * @return the code for do activity behaviors (if any)
   */
  public static void getEffectBehaviors(final StateMachine stateMachine) {
    ArrayList<Transition> transitions = JavaStateMachine.getTransitions(stateMachine);
    String effectBehaviorCode = "";
  }
  
  /**
   * Get JavaBehavior from opaque behavior
   * @param behavior the behavior to investigate for Java Behavior
   * @return a Java behavior implementation if there is any
   */
  public static String getJavaBehavior(final Behavior behavior) {
    if ((behavior instanceof OpaqueBehavior)) {
      final OpaqueBehavior opaqueBehavior = ((OpaqueBehavior) behavior);
      int _size = opaqueBehavior.getBodies().size();
      int _size_1 = opaqueBehavior.getLanguages().size();
      boolean _equals = (_size == _size_1);
      if (_equals) {
        final int i = opaqueBehavior.getLanguages().indexOf("JAVA");
        return opaqueBehavior.getBodies().get(i);
      }
    }
    return "";
  }
}
