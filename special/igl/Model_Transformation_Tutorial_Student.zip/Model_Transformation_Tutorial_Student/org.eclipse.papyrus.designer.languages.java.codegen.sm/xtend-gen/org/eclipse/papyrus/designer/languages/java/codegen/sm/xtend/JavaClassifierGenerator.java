/**
 * Copyright (c) 2006 - 2016 CEA LIST.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Shuai Li (CEA LIST) <shuai.li@cea.fr> - initial API and implementation
 */
package org.eclipse.papyrus.designer.languages.java.codegen.sm.xtend;

import com.google.common.base.Objects;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.papyrus.designer.languages.common.base.GenUtils;
import org.eclipse.papyrus.designer.languages.java.codegen.sm.transformation.JavaModelElementsCreator;
import org.eclipse.papyrus.designer.languages.java.codegen.sm.utils.JavaGenUtils;
import org.eclipse.papyrus.designer.languages.java.profile.PapyrusJava.StaticClassifier;
import org.eclipse.papyrus.designer.languages.java.profile.PapyrusJava.Strictfp;
import org.eclipse.uml2.uml.Behavior;
import org.eclipse.uml2.uml.BehavioredClassifier;
import org.eclipse.uml2.uml.Classifier;
import org.eclipse.uml2.uml.ConnectableElement;
import org.eclipse.uml2.uml.Connector;
import org.eclipse.uml2.uml.Element;
import org.eclipse.uml2.uml.Enumeration;
import org.eclipse.uml2.uml.Interface;
import org.eclipse.uml2.uml.Port;
import org.eclipse.uml2.uml.Property;
import org.eclipse.uml2.uml.StateMachine;
import org.eclipse.uml2.uml.Type;
import org.eclipse.uml2.uml.VisibilityKind;
import org.eclipse.uml2.uml.util.UMLUtil;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class JavaClassifierGenerator {
  public static List<String> getSortedIncludePathList(final Classifier classifier, final String prefix) {
    List<String> importPathList = IterableExtensions.<String>sort(JavaClassImportClassDeclaration.javaClassAllImports(classifier, prefix));
    return importPathList;
  }
  
  public static CharSequence generateClassCode(final Classifier classifier, final String prefix) {
    StringConcatenation _builder = new StringConcatenation();
    String _packageDeclaration = JavaClassifierGenerator.packageDeclaration(classifier, prefix);
    _builder.append(_packageDeclaration);
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.newLine();
    {
      List<String> _sortedIncludePathList = JavaClassifierGenerator.getSortedIncludePathList(classifier, prefix);
      for(final String path : _sortedIncludePathList) {
        String _importDirective = JavaImportUtil.importDirective(path);
        _builder.append(_importDirective);
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    String _javaImport = JavaImportUtil.javaImport(classifier);
    _builder.append(_javaImport);
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    JavaGenUtils.openNS(classifier);
    _builder.newLineIfNotEmpty();
    _builder.append("/************************************************************/");
    _builder.newLine();
    CharSequence _javaElementDoc = JavaDocumentation.javaElementDoc(classifier);
    _builder.append(_javaElementDoc);
    _builder.newLineIfNotEmpty();
    String _classVisibility = JavaClassifierGenerator.classVisibility(classifier);
    _builder.append(_classVisibility);
    String _classModifiers = JavaClassifierGenerator.classModifiers(classifier);
    _builder.append(_classModifiers);
    String _classifierType = JavaClassifierGenerator.classifierType(classifier);
    _builder.append(_classifierType);
    _builder.append(" ");
    String _name = classifier.getName();
    _builder.append(_name);
    CharSequence _templateSignature = JavaTemplates.templateSignature(classifier);
    _builder.append(_templateSignature);
    CharSequence _javaClassInheritedDeclarations = JavaClassInheritedDeclarations.javaClassInheritedDeclarations(classifier);
    _builder.append(_javaClassInheritedDeclarations);
    _builder.append(" {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t\t\t\t");
    {
      if ((classifier instanceof Enumeration)) {
        CharSequence _javaEnumerationLiterals = JavaEnumerations.javaEnumerationLiterals(((Enumeration) classifier));
        _builder.append(_javaEnumerationLiterals, "\t\t\t\t");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append("\t   ");
    _builder.newLine();
    _builder.append("\t   \t\t    ");
    Object _javaClassTypeAndEnum = JavaClassTypeAndEnum.javaClassTypeAndEnum(classifier);
    _builder.append(_javaClassTypeAndEnum, "\t   \t\t    ");
    _builder.newLineIfNotEmpty();
    _builder.append("\t   ");
    _builder.newLine();
    _builder.append("\t   \t\t\t");
    String _string = JavaClassAttributesDeclaration.javaClassAttributesDeclaration(classifier).toString();
    _builder.append(_string, "\t   \t\t\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t\t\t\t");
    String _string_1 = JavaClassOperationsDeclaration.javaClassOperationsDeclaration(classifier).toString();
    _builder.append(_string_1, "\t\t\t\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.newLine();
    {
      if (((classifier instanceof BehavioredClassifier) && (((BehavioredClassifier) classifier).getClassifierBehavior() instanceof StateMachine))) {
        Behavior _classifierBehavior = ((BehavioredClassifier) classifier).getClassifierBehavior();
        CharSequence _javaStateMachineGeneration = JavaStateMachine.javaStateMachineGeneration(((StateMachine) _classifierBehavior));
        _builder.append(_javaStateMachineGeneration);
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("}");
    _builder.newLine();
    return _builder;
  }
  
  public static String classifierType(final Classifier classifier) {
    if ((classifier instanceof Interface)) {
      return "interface";
    } else {
      if ((classifier instanceof Enumeration)) {
        return "enum";
      } else {
        return "class";
      }
    }
  }
  
  public static String classVisibility(final Classifier classifier) {
    Element _owner = classifier.getOwner();
    if ((_owner instanceof Classifier)) {
      return classifier.getVisibility().toString().toLowerCase();
    } else {
      VisibilityKind _visibility = classifier.getVisibility();
      boolean _equals = Objects.equal(_visibility, VisibilityKind.PUBLIC_LITERAL);
      if (_equals) {
        return "public";
      }
      return "";
    }
  }
  
  public static String classModifiers(final Classifier classifier) {
    String result = " ";
    if (((!(classifier instanceof Enumeration)) && (!(classifier instanceof Interface)))) {
      boolean _isAbstract = classifier.isAbstract();
      if (_isAbstract) {
        String _result = result;
        result = (_result + "abstract ");
      } else {
        boolean _isLeaf = classifier.isLeaf();
        if (_isLeaf) {
          String _result_1 = result;
          result = (_result_1 + "final ");
        }
      }
    }
    Element _owner = classifier.getOwner();
    if ((_owner instanceof Classifier)) {
      StaticClassifier _stereotypeApplication = UMLUtil.<StaticClassifier>getStereotypeApplication(classifier, StaticClassifier.class);
      boolean _tripleNotEquals = (_stereotypeApplication != null);
      if (_tripleNotEquals) {
        String _result_2 = result;
        result = (_result_2 + "static ");
      }
    }
    Strictfp _stereotypeApplication_1 = UMLUtil.<Strictfp>getStereotypeApplication(classifier, Strictfp.class);
    boolean _tripleNotEquals_1 = (_stereotypeApplication_1 != null);
    if (_tripleNotEquals_1) {
      String _result_3 = result;
      result = (_result_3 + "strictfp ");
    }
    return result;
  }
  
  public static String packageDeclaration(final Classifier classifier, final String prefix) {
    String _fullPath = GenUtils.getFullPath(classifier.getPackage(), ".", false);
    String qName = (prefix + _fullPath);
    boolean _endsWith = qName.endsWith(".");
    if (_endsWith) {
      int _length = qName.length();
      int _minus = (_length - 1);
      qName = qName.substring(0, _minus);
    }
    boolean _isEmpty = qName.isEmpty();
    if (_isEmpty) {
      return "";
    }
    return (("package " + qName) + ";");
  }
  
  public static boolean isMainClass(final Classifier classifier) {
    return ((classifier != null) && Objects.equal(classifier, JavaModelElementsCreator.mainClass));
  }
  
  public static boolean isNaoLib(final Property part) {
    if (((part != null) && (part.getType() instanceof Classifier))) {
      Type _type = part.getType();
      return JavaClassifierGenerator.isNaoLib(((Classifier) _type));
    }
    return false;
  }
  
  public static boolean isNaoLib(final Classifier classifier) {
    if ((classifier != null)) {
      if ((classifier.getQualifiedName().contains("Software") || classifier.getQualifiedName().contains("Hardware"))) {
        return true;
      }
    }
    return false;
  }
  
  public static boolean isAppClass(final Classifier classifier) {
    return ((!JavaClassifierGenerator.isMainClass(classifier)) && classifier.getQualifiedName().contains("Apps"));
  }
  
  public static String getConnectedNaoLibPartsNames(final Property part) {
    String result = "";
    if ((part != null)) {
      final ArrayList<Port> ports = JavaClassifierGenerator.getPortsOfPart(part);
      final ArrayList<Property> naoParts = new ArrayList<Property>();
      for (final Port port : ports) {
        {
          final Property otherEndPart = JavaClassifierGenerator.getOtherEndParts(port, part);
          boolean _isNaoLib = JavaClassifierGenerator.isNaoLib(otherEndPart);
          if (_isNaoLib) {
            for (int i = 0; (i < port.getRequireds().size()); i++) {
              naoParts.add(otherEndPart);
            }
          }
        }
      }
      for (int i = 0; (i < (naoParts.size() - 1)); i++) {
        String _result = result;
        String _name = naoParts.get(i).getName();
        String _plus = ("bootloader." + _name);
        String _plus_1 = (_plus + ", ");
        result = (_result + _plus_1);
      }
      String _result = result;
      int _size = naoParts.size();
      int _minus = (_size - 1);
      String _name = naoParts.get(_minus).getName();
      String _plus = ("bootloader." + _name);
      result = (_result + _plus);
    }
    return result;
  }
  
  public static ArrayList<Port> getPortsOfPart(final Property part) {
    ArrayList<Port> ports = new ArrayList<Port>();
    if ((part != null)) {
      Type _type = part.getType();
      if ((_type instanceof Classifier)) {
        Type _type_1 = part.getType();
        final Classifier type = ((Classifier) _type_1);
        Collection<Property> _ownedAttributes = JavaAttribute.getOwnedAttributes(type);
        for (final Property property : _ownedAttributes) {
          if ((property instanceof Port)) {
            ports.add(((Port) property));
          }
        }
      }
    }
    return ports;
  }
  
  public static Property getOtherEndParts(final Port thePort, final Property partWithPort) {
    Element _owner = partWithPort.getOwner();
    if ((_owner instanceof Classifier)) {
      Element _owner_1 = partWithPort.getOwner();
      final Classifier mainComposite = ((Classifier) _owner_1);
      EList<Element> _ownedElements = mainComposite.getOwnedElements();
      for (final Element element : _ownedElements) {
        if ((element instanceof Connector)) {
          final Connector connector = ((Connector) element);
          int _size = connector.getEnds().size();
          boolean _greaterThan = (_size > 1);
          if (_greaterThan) {
            ConnectableElement _role = connector.getEnds().get(0).getRole();
            boolean _equals = Objects.equal(_role, thePort);
            if (_equals) {
              Property _partWithPort = connector.getEnds().get(1).getPartWithPort();
              boolean _tripleNotEquals = (_partWithPort != null);
              if (_tripleNotEquals) {
                return connector.getEnds().get(1).getPartWithPort();
              }
            } else {
              ConnectableElement _role_1 = connector.getEnds().get(1).getRole();
              boolean _equals_1 = Objects.equal(_role_1, thePort);
              if (_equals_1) {
                Property _partWithPort_1 = connector.getEnds().get(0).getPartWithPort();
                boolean _tripleNotEquals_1 = (_partWithPort_1 != null);
                if (_tripleNotEquals_1) {
                  return connector.getEnds().get(0).getPartWithPort();
                }
              }
            }
          }
        }
      }
    }
    return null;
  }
  
  public static String appClassConstructorParameters(final Classifier classifier) {
    String result = "";
    Collection<Property> _ownedAttributes = JavaAttribute.getOwnedAttributes(classifier);
    for (final Property attr : _ownedAttributes) {
      if ((attr instanceof Port)) {
        Port port = ((Port) attr);
        int _size = port.getRequireds().size();
        boolean _equals = (_size == 1);
        if (_equals) {
          String _result = result;
          String _javaQualifiedName = JavaGenUtils.javaQualifiedName(port.getRequireds().get(0), port.getOwner());
          String _plus = (_javaQualifiedName + " ");
          String _name = port.getName();
          String _plus_1 = (_plus + _name);
          String _plus_2 = (_plus_1 + ", ");
          result = (_result + _plus_2);
        } else {
          int i = 0;
          EList<Interface> _requireds = port.getRequireds();
          for (final Interface itf : _requireds) {
            {
              String _result_1 = result;
              String _javaQualifiedName_1 = JavaGenUtils.javaQualifiedName(itf, port.getOwner());
              String _plus_3 = (_javaQualifiedName_1 + " ");
              String _name_1 = port.getName();
              String _plus_4 = (_plus_3 + _name_1);
              String _plus_5 = (_plus_4 + Integer.valueOf(i));
              String _plus_6 = (_plus_5 + ", ");
              result = (_result_1 + _plus_6);
              i++;
            }
          }
        }
      }
    }
    int _length = result.length();
    boolean _greaterThan = (_length > 2);
    if (_greaterThan) {
      int _length_1 = result.length();
      int _minus = (_length_1 - 2);
      result = result.substring(0, _minus);
    }
    return result;
  }
  
  public static String appClassConstructorBody(final Classifier classifier) {
    String result = "";
    Collection<Property> _ownedAttributes = JavaAttribute.getOwnedAttributes(classifier);
    for (final Property attr : _ownedAttributes) {
      if ((attr instanceof Port)) {
        Port port = ((Port) attr);
        int _size = port.getRequireds().size();
        boolean _equals = (_size == 1);
        if (_equals) {
          String _result = result;
          StringConcatenation _builder = new StringConcatenation();
          _builder.append("this.");
          String _name = port.getName();
          _builder.append(_name);
          _builder.append(" = ");
          String _name_1 = port.getName();
          _builder.append(_name_1);
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          result = (_result + _builder);
        } else {
          int i = 0;
          EList<Interface> _requireds = port.getRequireds();
          for (final Interface itf : _requireds) {
            {
              String _result_1 = result;
              StringConcatenation _builder_1 = new StringConcatenation();
              _builder_1.append("this.");
              String _name_2 = port.getName();
              String _plus = (_name_2 + Integer.valueOf(i));
              _builder_1.append(_plus);
              _builder_1.append(" = ");
              String _name_3 = port.getName();
              String _plus_1 = (_name_3 + Integer.valueOf(i));
              _builder_1.append(_plus_1);
              _builder_1.append(";");
              _builder_1.newLineIfNotEmpty();
              result = (_result_1 + _builder_1);
              i++;
            }
          }
        }
      }
    }
    return result;
  }
}
