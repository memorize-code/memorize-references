/**
 * Copyright (c) 2006 - 2016 CEA LIST.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Shuai Li (CEA LIST) <shuai.li@cea.fr> - initial API and implementation
 */
package org.eclipse.papyrus.designer.languages.java.codegen.sm.xtend;

import java.util.Collection;
import org.eclipse.emf.common.util.EList;
import org.eclipse.papyrus.designer.languages.java.codegen.sm.utils.JavaGenUtils;
import org.eclipse.papyrus.designer.languages.java.codegen.sm.utils.Modifier;
import org.eclipse.uml2.uml.Classifier;
import org.eclipse.uml2.uml.DataType;
import org.eclipse.uml2.uml.Interface;
import org.eclipse.uml2.uml.Port;
import org.eclipse.uml2.uml.Property;
import org.eclipse.uml2.uml.Signal;
import org.eclipse.uml2.uml.Type;
import org.eclipse.uml2.uml.ValueSpecification;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;

@SuppressWarnings("all")
public class JavaAttribute {
  public static Collection<Property> getOwnedAttributes(final Classifier cl) {
    Collection<Property> _xblockexpression = null;
    {
      final EList<Property> attributes = JavaAttribute.getOwnedAttributesWNull(cl);
      Collection<Property> _xifexpression = null;
      if ((attributes == null)) {
        _xifexpression = CollectionLiterals.<Property>emptySet();
      } else {
        _xifexpression = attributes;
      }
      _xblockexpression = _xifexpression;
    }
    return _xblockexpression;
  }
  
  public static EList<Property> getOwnedAttributesWNull(final Classifier cl) {
    EList<Property> _xifexpression = null;
    if ((cl instanceof org.eclipse.uml2.uml.Class)) {
      _xifexpression = ((org.eclipse.uml2.uml.Class) cl).getOwnedAttributes();
    } else {
      EList<Property> _xifexpression_1 = null;
      if ((cl instanceof DataType)) {
        _xifexpression_1 = ((DataType) cl).getOwnedAttributes();
      } else {
        EList<Property> _xifexpression_2 = null;
        if ((cl instanceof Interface)) {
          _xifexpression_2 = ((Interface) cl).getOwnedAttributes();
        } else {
          EList<Property> _xifexpression_3 = null;
          if ((cl instanceof Signal)) {
            _xifexpression_3 = ((Signal) cl).getOwnedAttributes();
          } else {
            _xifexpression_3 = null;
          }
          _xifexpression_2 = _xifexpression_3;
        }
        _xifexpression_1 = _xifexpression_2;
      }
      _xifexpression = _xifexpression_1;
    }
    return _xifexpression;
  }
  
  public static String defaultValue(final Property attribute) {
    String _xifexpression = null;
    ValueSpecification _defaultValue = attribute.getDefaultValue();
    boolean _tripleNotEquals = (_defaultValue != null);
    if (_tripleNotEquals) {
      String _stringValue = attribute.getDefaultValue().stringValue();
      _xifexpression = (" =" + _stringValue);
    }
    return _xifexpression;
  }
  
  public static CharSequence javaAttributeDeclaration(final Property attribute) {
    StringConcatenation _builder = new StringConcatenation();
    CharSequence _javaElementDoc = JavaDocumentation.javaElementDoc(attribute);
    _builder.append(_javaElementDoc);
    _builder.newLineIfNotEmpty();
    String _attributeModifiers = Modifier.attributeModifiers(attribute);
    _builder.append(_attributeModifiers);
    String _javaQualifiedName = JavaGenUtils.javaQualifiedName(attribute.getType(), attribute.getOwner());
    _builder.append(_javaQualifiedName);
    String _modArray = Modifier.modArray(attribute);
    _builder.append(_modArray);
    _builder.append(" ");
    String _name = attribute.getName();
    _builder.append(_name);
    String _defaultValue = JavaAttribute.defaultValue(attribute);
    _builder.append(_defaultValue);
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  public static CharSequence javaAttributeDeclaration(final Property attribute, final Type type) {
    StringConcatenation _builder = new StringConcatenation();
    CharSequence _javaElementDoc = JavaDocumentation.javaElementDoc(attribute);
    _builder.append(_javaElementDoc);
    _builder.newLineIfNotEmpty();
    String _attributeModifiers = Modifier.attributeModifiers(attribute);
    _builder.append(_attributeModifiers);
    String _javaQualifiedName = JavaGenUtils.javaQualifiedName(type, attribute.getOwner());
    _builder.append(_javaQualifiedName);
    String _modArray = Modifier.modArray(attribute);
    _builder.append(_modArray);
    _builder.append(" ");
    String _name = attribute.getName();
    _builder.append(_name);
    String _defaultValue = JavaAttribute.defaultValue(attribute);
    _builder.append(_defaultValue);
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
  
  public static CharSequence javaPortDeclaration(final Port port) {
    boolean _isEmpty = port.getRequireds().isEmpty();
    if (_isEmpty) {
      return "";
    } else {
      int _size = port.getRequireds().size();
      boolean _equals = (_size == 1);
      if (_equals) {
        return JavaAttribute.javaAttributeDeclaration(port, port.getRequireds().get(0));
      } else {
        String result = "";
        int i = 0;
        EList<Interface> _requireds = port.getRequireds();
        for (final Interface itf : _requireds) {
          {
            String _result = result;
            StringConcatenation _builder = new StringConcatenation();
            CharSequence _javaElementDoc = JavaDocumentation.javaElementDoc(port);
            _builder.append(_javaElementDoc);
            _builder.newLineIfNotEmpty();
            String _attributeModifiers = Modifier.attributeModifiers(port);
            _builder.append(_attributeModifiers);
            String _javaQualifiedName = JavaGenUtils.javaQualifiedName(itf, port.getOwner());
            _builder.append(_javaQualifiedName);
            String _modArray = Modifier.modArray(port);
            _builder.append(_modArray);
            _builder.append(" ");
            String _name = port.getName();
            String _plus = (_name + Integer.valueOf(i));
            _builder.append(_plus);
            String _defaultValue = JavaAttribute.defaultValue(port);
            _builder.append(_defaultValue);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.newLine();
            result = (_result + _builder);
            i++;
          }
        }
        return result;
      }
    }
  }
}
