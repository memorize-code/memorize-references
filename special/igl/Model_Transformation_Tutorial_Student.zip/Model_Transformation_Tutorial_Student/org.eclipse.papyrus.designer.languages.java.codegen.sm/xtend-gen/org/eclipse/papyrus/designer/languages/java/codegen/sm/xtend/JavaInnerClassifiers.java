/**
 * Copyright (c) 2006 - 2016 CEA LIST.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Shuai Li (CEA LIST) <shuai.li@cea.fr> - initial API and implementation
 */
package org.eclipse.papyrus.designer.languages.java.codegen.sm.xtend;

import org.eclipse.uml2.uml.Classifier;
import org.eclipse.uml2.uml.Enumeration;
import org.eclipse.xtend2.lib.StringConcatenation;

@SuppressWarnings("all")
public class JavaInnerClassifiers {
  public static CharSequence javaInnerClassDefinition(final Classifier classifier) {
    StringConcatenation _builder = new StringConcatenation();
    CharSequence _javaElementDoc = JavaDocumentation.javaElementDoc(classifier);
    _builder.append(_javaElementDoc);
    _builder.newLineIfNotEmpty();
    String _classVisibility = JavaClassifierGenerator.classVisibility(classifier);
    _builder.append(_classVisibility);
    String _classModifiers = JavaClassifierGenerator.classModifiers(classifier);
    _builder.append(_classModifiers);
    String _classifierType = JavaClassifierGenerator.classifierType(classifier);
    _builder.append(_classifierType);
    _builder.append(" ");
    String _name = classifier.getName();
    _builder.append(_name);
    CharSequence _templateSignature = JavaTemplates.templateSignature(classifier);
    _builder.append(_templateSignature);
    CharSequence _javaClassInheritedDeclarations = JavaClassInheritedDeclarations.javaClassInheritedDeclarations(classifier);
    _builder.append(_javaClassInheritedDeclarations);
    _builder.append(" {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    {
      if ((classifier instanceof Enumeration)) {
        CharSequence _javaEnumerationLiterals = JavaEnumerations.javaEnumerationLiterals(((Enumeration) classifier));
        _builder.append(_javaEnumerationLiterals, "\t");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append("    ");
    Object _javaClassTypeAndEnum = JavaClassTypeAndEnum.javaClassTypeAndEnum(classifier);
    _builder.append(_javaClassTypeAndEnum, "    ");
    _builder.newLineIfNotEmpty();
    _builder.append("    \t\t\t");
    String _string = JavaClassAttributesDeclaration.javaClassAttributesDeclaration(classifier).toString();
    _builder.append(_string, "    \t\t\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    String _string_1 = JavaClassOperationsDeclaration.javaClassOperationsDeclaration(classifier).toString();
    _builder.append(_string_1, "\t");
    _builder.newLineIfNotEmpty();
    _builder.append("};");
    _builder.newLine();
    return _builder;
  }
}
