/**
 * Copyright (c) 2006 - 2016 CEA LIST.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Shuai Li (CEA LIST) <shuai.li@cea.fr> - initial API and implementation
 */
package org.eclipse.papyrus.designer.languages.java.codegen.sm.xtend;

import org.eclipse.uml2.uml.Enumeration;
import org.eclipse.uml2.uml.EnumerationLiteral;
import org.eclipse.uml2.uml.ValueSpecification;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.ExclusiveRange;

@SuppressWarnings("all")
public class JavaEnumerations {
  public static CharSequence javaEnumerationLiterals(final Enumeration enumeration) {
    StringConcatenation _builder = new StringConcatenation();
    {
      int _size = enumeration.getOwnedLiterals().size();
      ExclusiveRange _doubleDotLessThan = new ExclusiveRange(0, _size, true);
      for(final Integer i : _doubleDotLessThan) {
        CharSequence _javaElementDoc = JavaDocumentation.javaElementDoc(enumeration.getOwnedLiterals().get((i).intValue()));
        _builder.append(_javaElementDoc);
        _builder.newLineIfNotEmpty();
        String _name = enumeration.getOwnedLiterals().get((i).intValue()).getName();
        _builder.append(_name);
        String _defaultValue = JavaEnumerations.defaultValue(enumeration.getOwnedLiterals().get((i).intValue()));
        _builder.append(_defaultValue);
        {
          int _size_1 = enumeration.getOwnedLiterals().size();
          int _minus = (_size_1 - 1);
          boolean _lessThan = ((i).intValue() < _minus);
          if (_lessThan) {
            _builder.append(",");
          } else {
            _builder.append(";");
          }
        }
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
  
  public static String defaultValue(final EnumerationLiteral literal) {
    String _xifexpression = null;
    ValueSpecification _specification = literal.getSpecification();
    boolean _tripleNotEquals = (_specification != null);
    if (_tripleNotEquals) {
      _xifexpression = literal.getSpecification().stringValue();
    }
    return _xifexpression;
  }
}
