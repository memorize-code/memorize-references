/**
 * Copyright (c) 2006 - 2016 CEA LIST.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Shuai Li (CEA LIST) <shuai.li@cea.fr> - initial API and implementation
 */
package org.eclipse.papyrus.designer.languages.java.codegen.sm.xtend;

import org.eclipse.emf.common.util.EList;
import org.eclipse.papyrus.designer.languages.common.base.GenUtils;
import org.eclipse.papyrus.designer.languages.common.profile.Codegen.NoCodeGen;
import org.eclipse.uml2.uml.Classifier;
import org.eclipse.uml2.uml.Element;
import org.eclipse.uml2.uml.Enumeration;
import org.eclipse.uml2.uml.Interface;
import org.eclipse.uml2.uml.UMLFactory;
import org.eclipse.xtend2.lib.StringConcatenation;

@SuppressWarnings("all")
public class JavaClassTypeAndEnum {
  public static Object javaClassTypeAndEnum(final Classifier clazz) {
    StringConcatenation _builder = new StringConcatenation();
    {
      EList<Element> _ownedElements = clazz.getOwnedElements();
      for(final Element ownedElement : _ownedElements) {
        CharSequence _typeAndEnum = JavaClassTypeAndEnum.typeAndEnum(ownedElement);
        _builder.append(_typeAndEnum);
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
  
  public static CharSequence typeAndEnum(final Element element) {
    if (((!GenUtils.hasStereotype(element, NoCodeGen.class)) && (element instanceof Classifier))) {
      if (((((element instanceof Enumeration) || (element instanceof Interface)) || element.eClass().equals(UMLFactory.eINSTANCE.getUMLPackage().getClass_())) && (!(element.getOwner() instanceof org.eclipse.uml2.uml.Package)))) {
        return JavaInnerClassifiers.javaInnerClassDefinition(((Classifier) element));
      }
    }
    return null;
  }
}
