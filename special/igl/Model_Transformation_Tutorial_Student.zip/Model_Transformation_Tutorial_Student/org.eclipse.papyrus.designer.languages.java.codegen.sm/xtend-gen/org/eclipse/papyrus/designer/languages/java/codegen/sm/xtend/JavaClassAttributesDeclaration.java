/**
 * Copyright (c) 2006 - 2016 CEA LIST.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Shuai Li (CEA LIST) <shuai.li@cea.fr> - initial API and implementation
 */
package org.eclipse.papyrus.designer.languages.java.codegen.sm.xtend;

import java.util.Collection;
import org.eclipse.uml2.uml.Classifier;
import org.eclipse.uml2.uml.Port;
import org.eclipse.uml2.uml.Property;
import org.eclipse.xtend2.lib.StringConcatenation;

@SuppressWarnings("all")
public class JavaClassAttributesDeclaration {
  public static CharSequence javaClassAttributesDeclaration(final Classifier clazz) {
    StringConcatenation _builder = new StringConcatenation();
    {
      Collection<Property> _ownedAttributes = JavaAttribute.getOwnedAttributes(clazz);
      for(final Property oa : _ownedAttributes) {
        {
          if ((oa instanceof Port)) {
            CharSequence _javaPortDeclaration = JavaAttribute.javaPortDeclaration(((Port)oa));
            _builder.append(_javaPortDeclaration);
            _builder.newLineIfNotEmpty();
          } else {
            CharSequence _javaAttributeDeclaration = JavaAttribute.javaAttributeDeclaration(oa);
            _builder.append(_javaAttributeDeclaration);
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    return _builder;
  }
}
